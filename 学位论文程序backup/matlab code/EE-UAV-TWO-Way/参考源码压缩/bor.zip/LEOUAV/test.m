C0=db2pow(-30);d0=1;d=8e5;a=2;
shadowedricianRV=ShadowedRicianRVGenerator(20,0.005,26,0.515);
shadowedricianRV=sqrt(C0*(d0/d)^a)*shadowedricianRV;