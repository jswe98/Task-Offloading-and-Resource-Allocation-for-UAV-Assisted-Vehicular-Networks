rng(2);
s=sqrt(1/2)*(randn(1,10)+1j*randn(1,10))